/*
 * Author: Maya Lavi
 * Date: 2.14.19
 * Description: This program finds the discriminant and roots of a quadratic equation in standard form
 */

package maya;

import java.util.Scanner;

public class QuadraticEquation {
	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		//roots + discriminant
		double root1;
		double root2;
		double discriminant;
		//constant variables
		double aVar;
		double bVar;
		double cVar;
		
		System.out.println("\n\t\t\tWelcome to Quadratic 3000");
		System.out.println("\nThis program finds the discriminant and roots of a quadratic equation in standard form \'y=a*x^2 + b*x + c\'\n");
		System.out.println("Input value for a:");
		aVar = scnr.nextDouble();
		System.out.println("Input value for b:");
		bVar = scnr.nextDouble();
		System.out.println("Input value for c:");
		cVar = scnr.nextDouble();
		
		discriminant = Math.pow(bVar, 2) - (4 * aVar * cVar);
		root1 = (-bVar + Math.sqrt(discriminant)) / (2 * aVar);
		root2 = (-bVar - Math.sqrt(discriminant)) / (2 * aVar);
		
		System.out.println("Discriminant = " + discriminant);
		System.out.println("Roots = " + root1 + ", " + root2);

		
		
	}
	
}
